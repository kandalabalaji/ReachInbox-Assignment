import React from 'react';
import { Search, Filter, X } from 'lucide-react';

interface SearchFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  selectedAccount: string;
  onAccountChange: (account: string) => void;
  selectedFolder: string;
  onFolderChange: (folder: string) => void;
}

const SearchFilters: React.FC<SearchFiltersProps> = ({
  searchQuery,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  selectedAccount,
  onAccountChange,
  selectedFolder,
  onFolderChange
}) => {
  const categories = [
    'All Categories',
    'Interested',
    'Meeting Booked',
    'Not Interested',
    'Spam',
    'Out of Office',
    'Uncategorized'
  ];

  const accounts = [
    'All Accounts',
    'john@company.com',
    'sales@company.com'
  ];

  const folders = [
    'All Folders',
    'Inbox',
    'Sent',
    'Archive',
    'Trash'
  ];

  const hasActiveFilters = selectedCategory !== 'All Categories' || 
                          selectedAccount !== 'All Accounts' || 
                          selectedFolder !== 'All Folders' ||
                          searchQuery.length > 0;

  const clearAllFilters = () => {
    onSearchChange('');
    onCategoryChange('All Categories');
    onAccountChange('All Accounts');
    onFolderChange('All Folders');
  };

  return (
    <div className="bg-white border-b border-slate-200 p-4">
      <div className="flex items-center space-x-4">
        {/* Search Input */}
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search emails by subject, content, or sender..."
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
        </div>

        {/* Category Filter */}
        <div className="relative">
          <select
            value={selectedCategory}
            onChange={(e) => onCategoryChange(e.target.value)}
            className="appearance-none bg-white border border-slate-300 rounded-lg px-4 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {categories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>

        {/* Account Filter */}
        <div className="relative">
          <select
            value={selectedAccount}
            onChange={(e) => onAccountChange(e.target.value)}
            className="appearance-none bg-white border border-slate-300 rounded-lg px-4 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {accounts.map((account) => (
              <option key={account} value={account}>
                {account}
              </option>
            ))}
          </select>
        </div>

        {/* Folder Filter */}
        <div className="relative">
          <select
            value={selectedFolder}
            onChange={(e) => onFolderChange(e.target.value)}
            className="appearance-none bg-white border border-slate-300 rounded-lg px-4 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            {folders.map((folder) => (
              <option key={folder} value={folder}>
                {folder}
              </option>
            ))}
          </select>
        </div>

        {/* Clear Filters */}
        {hasActiveFilters && (
          <button
            onClick={clearAllFilters}
            className="flex items-center px-3 py-2 text-sm text-slate-600 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
          >
            <X className="h-4 w-4 mr-1" />
            Clear
          </button>
        )}

        {/* Filter Icon */}
        <div className="flex items-center text-slate-400">
          <Filter className="h-4 w-4" />
        </div>
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="mt-3 flex items-center space-x-2">
          <span className="text-sm text-slate-500">Active filters:</span>
          {searchQuery && (
            <span className="inline-flex items-center px-2 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full">
              Search: "{searchQuery}"
            </span>
          )}
          {selectedCategory !== 'All Categories' && (
            <span className="inline-flex items-center px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
              Category: {selectedCategory}
            </span>
          )}
          {selectedAccount !== 'All Accounts' && (
            <span className="inline-flex items-center px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
              Account: {selectedAccount}
            </span>
          )}
          {selectedFolder !== 'All Folders' && (
            <span className="inline-flex items-center px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">
              Folder: {selectedFolder}
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchFilters;