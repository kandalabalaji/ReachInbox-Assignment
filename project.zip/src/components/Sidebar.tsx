import React from 'react';
import { Inbox, Send, Archive, Trash2, Tag, Users, BarChart3 } from 'lucide-react';

interface SidebarProps {
  selectedFolder: string;
  onFolderSelect: (folder: string) => void;
  selectedAccount: string;
  onAccountSelect: (account: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  selectedFolder,
  onFolderSelect,
  selectedAccount,
  onAccountSelect
}) => {
  const folders = [
    { id: 'inbox', name: 'Inbox', icon: Inbox, count: 24 },
    { id: 'sent', name: 'Sent', icon: Send, count: 12 },
    { id: 'archive', name: 'Archive', icon: Archive, count: 156 },
    { id: 'trash', name: 'Trash', icon: Trash2, count: 8 }
  ];

  const accounts = [
    { id: 'account1', name: 'john@company.com', status: 'connected' },
    { id: 'account2', name: 'sales@company.com', status: 'connected' }
  ];

  const categories = [
    { name: 'Interested', count: 8, color: 'bg-green-500' },
    { name: 'Meeting Booked', count: 3, color: 'bg-blue-500' },
    { name: 'Not Interested', count: 12, color: 'bg-red-500' },
    { name: 'Spam', count: 5, color: 'bg-yellow-500' },
    { name: 'Out of Office', count: 2, color: 'bg-purple-500' }
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 h-full overflow-y-auto">
      <div className="p-4">
        {/* Accounts Section */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-zinc-800 mb-3 flex items-center">
            <Users className="h-4 w-4 mr-2" />
            Email Accounts
          </h3>
          <div className="space-y-2">
            {accounts.map((account) => (
              <button
                key={account.id}
                onClick={() => onAccountSelect(account.id)}
                className={`w-full text-left p-2 rounded-lg transition-colors ${
                  selectedAccount === account.id
                    ? 'bg-indigo-50 text-indigo-600 border border-indigo-200'
                    : 'hover:bg-slate-50 text-slate-600'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium truncate">{account.name}</span>
                  <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Folders Section */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-zinc-800 mb-3">Folders</h3>
          <nav className="space-y-1">
            {folders.map((folder) => {
              const Icon = folder.icon;
              return (
                <button
                  key={folder.id}
                  onClick={() => onFolderSelect(folder.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors ${
                    selectedFolder === folder.id
                      ? 'bg-indigo-50 text-indigo-600 border border-indigo-200'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center">
                    <Icon className="h-4 w-4 mr-3" />
                    {folder.name}
                  </div>
                  <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-full">
                    {folder.count}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* AI Categories Section */}
        <div>
          <h3 className="text-sm font-semibold text-zinc-800 mb-3 flex items-center">
            <Tag className="h-4 w-4 mr-2" />
            AI Categories
          </h3>
          <div className="space-y-2">
            {categories.map((category) => (
              <div key={category.name} className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50">
                <div className="flex items-center">
                  <div className={`h-3 w-3 rounded-full ${category.color} mr-3`}></div>
                  <span className="text-sm text-slate-600">{category.name}</span>
                </div>
                <span className="text-xs text-slate-400">{category.count}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-6 p-3 bg-slate-50 rounded-lg">
          <div className="flex items-center mb-2">
            <BarChart3 className="h-4 w-4 text-slate-400 mr-2" />
            <span className="text-sm font-medium text-slate-600">Today's Stats</span>
          </div>
          <div className="text-xs text-slate-500 space-y-1">
            <div className="flex justify-between">
              <span>Synced:</span>
              <span className="font-medium">47 emails</span>
            </div>
            <div className="flex justify-between">
              <span>Categorized:</span>
              <span className="font-medium">45 emails</span>
            </div>
            <div className="flex justify-between">
              <span>Interested:</span>
              <span className="font-medium text-green-600">8 leads</span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;