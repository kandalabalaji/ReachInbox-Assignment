import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-zinc-800 text-white py-8 mt-auto">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-lg font-semibold mb-4">ReachInbox AI Email Onebox</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Transform your cold outreach with our revolutionary AI-driven platform. 
              Sync multiple IMAP accounts, get AI-powered categorization, and receive 
              intelligent reply suggestions powered by RAG technology.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Features</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>Real-time IMAP Sync</li>
              <li>AI Email Categorization</li>
              <li>Elasticsearch Integration</li>
              <li>Smart Reply Suggestions</li>
              <li>Slack Notifications</li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Technology</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>TypeScript & Node.js</li>
              <li>React & Tailwind CSS</li>
              <li>Elasticsearch</li>
              <li>Vector Database (RAG)</li>
              <li>Gemini AI API</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="text-sm text-slate-400">
            © 2025 ReachInbox AI Email Onebox. All rights reserved.
          </div>
          <div className="text-sm text-slate-400 mt-4 md:mt-0">
            Built with ❤️ by <a href="https://meku.dev" target="_blank" rel="nofollow" className="text-indigo-400 hover:text-indigo-300 transition-colors">Meku.dev</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;