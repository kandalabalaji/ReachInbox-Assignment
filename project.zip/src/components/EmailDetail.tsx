import React, { useState } from 'react';
import { ArrowLeft, Reply, Forward, Archive, Trash2, Star, MoreHorizontal, Sparkles } from 'lucide-react';
import { format } from 'date-fns';

interface Email {
  id: string;
  subject: string;
  from: string;
  to: string[];
  body: string;
  date: Date;
  aiCategory: 'Interested' | 'Meeting Booked' | 'Not Interested' | 'Spam' | 'Out of Office' | 'Uncategorized';
  hasAttachment: boolean;
  isRead: boolean;
  isStarred: boolean;
}

interface EmailDetailProps {
  email: Email;
  onBack: () => void;
  onSuggestReply: (emailId: string) => void;
}

const EmailDetail: React.FC<EmailDetailProps> = ({ email, onBack, onSuggestReply }) => {
  const [showSuggestedReply, setShowSuggestedReply] = useState(false);
  const [suggestedReply, setSuggestedReply] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Interested': return 'bg-green-100 text-green-800 border-green-200';
      case 'Meeting Booked': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Not Interested': return 'bg-red-100 text-red-800 border-red-200';
      case 'Spam': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Out of Office': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const handleSuggestReply = async () => {
    setIsGenerating(true);
    setShowSuggestedReply(true);
    
    // Simulate AI reply generation
    setTimeout(() => {
      setSuggestedReply(`Thank you for your interest in our services! I'd be happy to discuss how we can help you achieve your goals.

Based on your inquiry, I believe our solution would be a great fit for your needs. I'd love to schedule a brief call to understand your requirements better and show you how we can add value to your business.

You can book a convenient time slot here: https://cal.com/reachinbox-demo

Looking forward to connecting with you soon!

Best regards,
Sales Team`);
      setIsGenerating(false);
    }, 2000);
  };

  return (
    <div className="flex-1 bg-white flex flex-col">
      {/* Header */}
      <div className="border-b border-slate-200 p-4">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={onBack}
            className="flex items-center text-slate-600 hover:text-zinc-800 transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to emails
          </button>
          
          <div className="flex items-center space-x-2">
            <button className="p-2 text-slate-400 hover:text-zinc-800 transition-colors">
              <Star className="h-4 w-4" />
            </button>
            <button className="p-2 text-slate-400 hover:text-zinc-800 transition-colors">
              <Archive className="h-4 w-4" />
            </button>
            <button className="p-2 text-slate-400 hover:text-zinc-800 transition-colors">
              <Trash2 className="h-4 w-4" />
            </button>
            <button className="p-2 text-slate-400 hover:text-zinc-800 transition-colors">
              <MoreHorizontal className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-zinc-800 mb-2">{email.subject}</h1>
            <div className="flex items-center space-x-4 text-sm text-slate-600">
              <span>From: <strong>{email.from}</strong></span>
              <span>To: <strong>{email.to.join(', ')}</strong></span>
              <span>{format(email.date, 'MMM d, yyyy at HH:mm')}</span>
            </div>
          </div>
          
          <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getCategoryColor(email.aiCategory)}`}>
            {email.aiCategory}
          </span>
        </div>
      </div>

      {/* Email Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl">
          <div className="prose prose-slate max-w-none">
            <div className="whitespace-pre-wrap text-slate-700 leading-relaxed">
              {email.body}
            </div>
          </div>
        </div>
      </div>

      {/* AI Suggested Reply Section */}
      {email.aiCategory === 'Interested' && (
        <div className="border-t border-slate-200 p-4 bg-slate-50">
          {!showSuggestedReply ? (
            <div className="text-center">
              <button
                onClick={handleSuggestReply}
                className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                <Sparkles className="h-4 w-4 mr-2" />
                Generate AI Reply Suggestion
              </button>
              <p className="text-sm text-slate-500 mt-2">
                Get an AI-powered reply suggestion based on your product data and outreach agenda
              </p>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-zinc-800 flex items-center">
                  <Sparkles className="h-4 w-4 mr-2 text-indigo-600" />
                  AI Suggested Reply
                </h3>
                <span className="text-xs text-slate-500">Powered by RAG + LLM</span>
              </div>
              
              {isGenerating ? (
                <div className="bg-white border border-slate-200 rounded-lg p-4">
                  <div className="animate-pulse">
                    <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-slate-200 rounded w-1/2 mb-2"></div>
                    <div className="h-4 bg-slate-200 rounded w-5/6"></div>
                  </div>
                  <p className="text-sm text-slate-500 mt-2">Generating personalized reply...</p>
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-lg p-4">
                  <textarea
                    value={suggestedReply}
                    onChange={(e) => setSuggestedReply(e.target.value)}
                    className="w-full h-48 text-sm text-slate-700 border-none resize-none focus:outline-none"
                    placeholder="AI suggested reply will appear here..."
                  />
                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-100">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
                        Context: Meeting booking link retrieved
                      </span>
                      <span className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
                        Tone: Professional & Helpful
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button className="px-3 py-1 text-sm text-slate-600 border border-slate-300 rounded hover:bg-slate-50 transition-colors">
                        Regenerate
                      </button>
                      <button className="px-3 py-1 text-sm bg-indigo-600 text-white rounded hover:bg-indigo-700 transition-colors">
                        Use Reply
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Action Buttons */}
      <div className="border-t border-slate-200 p-4 bg-white">
        <div className="flex items-center space-x-3">
          <button className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
            <Reply className="h-4 w-4 mr-2" />
            Reply
          </button>
          <button className="flex items-center px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors">
            <Forward className="h-4 w-4 mr-2" />
            Forward
          </button>
        </div>
      </div>
    </div>
  );
};

export default EmailDetail;