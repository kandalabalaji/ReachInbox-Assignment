import React from 'react';
import { Clock, Paperclip, Star, Reply } from 'lucide-react';
import { format } from 'date-fns';

interface Email {
  id: string;
  subject: string;
  from: string;
  to: string[];
  body: string;
  date: Date;
  aiCategory: 'Interested' | 'Meeting Booked' | 'Not Interested' | 'Spam' | 'Out of Office' | 'Uncategorized';
  hasAttachment: boolean;
  isRead: boolean;
  isStarred: boolean;
}

interface EmailListProps {
  emails: Email[];
  selectedEmail: string | null;
  onEmailSelect: (emailId: string) => void;
  onSuggestReply: (emailId: string) => void;
}

const EmailList: React.FC<EmailListProps> = ({
  emails,
  selectedEmail,
  onEmailSelect,
  onSuggestReply
}) => {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Interested': return 'bg-green-100 text-green-800 border-green-200';
      case 'Meeting Booked': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Not Interested': return 'bg-red-100 text-red-800 border-red-200';
      case 'Spam': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Out of Office': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const truncateText = (text: string, maxLength: number) => {
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
  };

  return (
    <div className="flex-1 bg-white">
      <div className="border-b border-slate-200 p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-zinc-800">
            Emails ({emails.length})
          </h2>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-slate-500">Real-time sync active</span>
            <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>

      <div className="divide-y divide-slate-100">
        {emails.map((email) => (
          <div
            key={email.id}
            onClick={() => onEmailSelect(email.id)}
            className={`p-4 cursor-pointer transition-colors hover:bg-slate-50 ${
              selectedEmail === email.id ? 'bg-indigo-50 border-r-2 border-indigo-500' : ''
            } ${!email.isRead ? 'bg-blue-50/30' : ''}`}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2 mb-1">
                  <span className={`font-medium text-sm ${!email.isRead ? 'text-zinc-900' : 'text-zinc-700'}`}>
                    {email.from}
                  </span>
                  {email.isStarred && <Star className="h-4 w-4 text-yellow-500 fill-current" />}
                  {email.hasAttachment && <Paperclip className="h-4 w-4 text-slate-400" />}
                </div>
                
                <h3 className={`text-sm mb-1 ${!email.isRead ? 'font-semibold text-zinc-900' : 'text-zinc-700'}`}>
                  {truncateText(email.subject, 60)}
                </h3>
                
                <p className="text-sm text-slate-500 mb-2">
                  {truncateText(email.body, 100)}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${getCategoryColor(email.aiCategory)}`}>
                      {email.aiCategory}
                    </span>
                    
                    {email.aiCategory === 'Interested' && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSuggestReply(email.id);
                        }}
                        className="inline-flex items-center px-2 py-1 text-xs font-medium text-indigo-600 bg-indigo-50 border border-indigo-200 rounded-full hover:bg-indigo-100 transition-colors"
                      >
                        <Reply className="h-3 w-3 mr-1" />
                        AI Reply
                      </button>
                    )}
                  </div>
                  
                  <div className="flex items-center text-xs text-slate-400">
                    <Clock className="h-3 w-3 mr-1" />
                    {format(email.date, 'MMM d, HH:mm')}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {emails.length === 0 && (
        <div className="flex flex-col items-center justify-center h-64 text-slate-500">
          <div className="text-center">
            <div className="h-12 w-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="h-6 w-6 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 mb-2">No emails found</h3>
            <p className="text-sm">Emails will appear here as they are synced from your accounts.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmailList;