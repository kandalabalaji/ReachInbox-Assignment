import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';
import SearchFilters from '../components/SearchFilters';
import EmailList from '../components/EmailList';
import EmailDetail from '../components/EmailDetail';
import Footer from '../components/Footer';

interface Email {
  id: string;
  subject: string;
  from: string;
  to: string[];
  body: string;
  date: Date;
  aiCategory: 'Interested' | 'Meeting Booked' | 'Not Interested' | 'Spam' | 'Out of Office' | 'Uncategorized';
  hasAttachment: boolean;
  isRead: boolean;
  isStarred: boolean;
  accountId: string;
  folder: string;
}

const Home: React.FC = () => {
  const [emails, setEmails] = useState<Email[]>([]);
  const [filteredEmails, setFilteredEmails] = useState<Email[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<string | null>(null);
  const [selectedFolder, setSelectedFolder] = useState('inbox');
  const [selectedAccount, setSelectedAccount] = useState('account1');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedFilterAccount, setSelectedFilterAccount] = useState('All Accounts');
  const [selectedFilterFolder, setSelectedFilterFolder] = useState('All Folders');

  // Mock email data
  useEffect(() => {
    const mockEmails: Email[] = [
      {
        id: '1',
        subject: 'Re: Partnership Opportunity - Very Interested!',
        from: 'sarah.johnson@techcorp.com',
        to: ['john@company.com'],
        body: `Hi John,

Thank you for reaching out about the partnership opportunity. I've reviewed your proposal and I'm very interested in moving forward with this collaboration.

Our team has been looking for exactly this type of solution, and your approach aligns perfectly with our current initiatives. I'd love to schedule a call to discuss the details further.

Could we set up a meeting sometime next week? I'm available Tuesday through Thursday, preferably in the afternoon.

Looking forward to hearing from you soon!

Best regards,
Sarah Johnson
Director of Business Development
TechCorp Solutions`,
        date: new Date('2025-01-15T10:30:00'),
        aiCategory: 'Interested',
        hasAttachment: false,
        isRead: false,
        isStarred: true,
        accountId: 'account1',
        folder: 'inbox'
      },
      {
        id: '2',
        subject: 'Meeting Confirmation - Tomorrow 2 PM',
        from: 'mike.chen@startup.io',
        to: ['sales@company.com'],
        body: `Hi there,

Just confirming our meeting scheduled for tomorrow (January 16th) at 2:00 PM EST. I've added the calendar invite and included the Zoom link.

We'll be discussing the implementation timeline and pricing structure as discussed in our previous call.

Attendees from our side:
- Mike Chen (CTO)
- Lisa Wang (Product Manager)
- David Kim (Lead Developer)

Please let me know if you need to reschedule or if you have any questions before our meeting.

Thanks!
Mike Chen
CTO, StartupIO`,
        date: new Date('2025-01-15T09:15:00'),
        aiCategory: 'Meeting Booked',
        hasAttachment: true,
        isRead: true,
        isStarred: false,
        accountId: 'account2',
        folder: 'inbox'
      },
      {
        id: '3',
        subject: 'Thanks, but not the right fit',
        from: 'alex.rodriguez@enterprise.com',
        to: ['john@company.com'],
        body: `Hello,

Thank you for your email regarding your services. While I appreciate you taking the time to reach out, we're not currently looking for this type of solution.

We have recently implemented a similar system and are satisfied with our current setup. Please remove me from your mailing list.

Best of luck with your business.

Alex Rodriguez
IT Director
Enterprise Corp`,
        date: new Date('2025-01-15T08:45:00'),
        aiCategory: 'Not Interested',
        hasAttachment: false,
        isRead: true,
        isStarred: false,
        accountId: 'account1',
        folder: 'inbox'
      },
      {
        id: '4',
        subject: 'Out of Office: Returning January 20th',
        from: 'jennifer.smith@bigcorp.com',
        to: ['sales@company.com'],
        body: `Thank you for your email.

I am currently out of the office and will return on Monday, January 20th, 2025. I will have limited access to email during this time.

If this is urgent, please contact my assistant, Mark Thompson, at mark.thompson@bigcorp.com or call (555) 123-4567.

I will respond to your message upon my return.

Best regards,
Jennifer Smith
VP of Operations
BigCorp Industries`,
        date: new Date('2025-01-15T07:20:00'),
        aiCategory: 'Out of Office',
        hasAttachment: false,
        isRead: true,
        isStarred: false,
        accountId: 'account2',
        folder: 'inbox'
      },
      {
        id: '5',
        subject: 'URGENT: Your account will be suspended!!!',
        from: 'noreply@suspicious-domain.xyz',
        to: ['john@company.com'],
        body: `URGENT ACTION REQUIRED!!!

Your account has been flagged for suspicious activity and will be suspended in 24 hours unless you verify your information immediately.

Click here to verify: http://suspicious-link.xyz/verify

Failure to act within 24 hours will result in permanent account closure and loss of all data.

This is an automated message. Do not reply to this email.

Security Team
[Suspicious Company]`,
        date: new Date('2025-01-15T06:10:00'),
        aiCategory: 'Spam',
        hasAttachment: false,
        isRead: false,
        isStarred: false,
        accountId: 'account1',
        folder: 'inbox'
      },
      {
        id: '6',
        subject: 'Love your product! When can we start?',
        from: 'emma.wilson@growth-co.com',
        to: ['sales@company.com'],
        body: `Hi team,

I came across your solution through a colleague's recommendation and I'm really impressed with what you've built!

We're a fast-growing company and have been struggling with the exact problem your product solves. After reviewing your website and case studies, I'm convinced this is exactly what we need.

A few quick questions:
1. What's the typical implementation timeline?
2. Do you offer training for our team?
3. Can we schedule a demo this week?

I'm excited to get started and would love to move quickly on this. Please let me know your availability.

Best,
Emma Wilson
Head of Operations
GrowthCo`,
        date: new Date('2025-01-14T16:30:00'),
        aiCategory: 'Interested',
        hasAttachment: false,
        isRead: true,
        isStarred: true,
        accountId: 'account2',
        folder: 'inbox'
      }
    ];

    setEmails(mockEmails);
    setFilteredEmails(mockEmails);

    // Simulate real-time email notifications
    const interestedEmails = mockEmails.filter(email => email.aiCategory === 'Interested');
    interestedEmails.forEach((email, index) => {
      setTimeout(() => {
        toast.success(`🎯 New interested lead: ${email.from}`, {
          position: "top-right",
          autoClose: 5000,
        });
      }, (index + 1) * 3000);
    });
  }, []);

  // Filter emails based on search and filters
  useEffect(() => {
    let filtered = emails;

    // Apply search query
    if (searchQuery) {
      filtered = filtered.filter(email =>
        email.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
        email.body.toLowerCase().includes(searchQuery.toLowerCase()) ||
        email.from.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply category filter
    if (selectedCategory !== 'All Categories') {
      filtered = filtered.filter(email => email.aiCategory === selectedCategory);
    }

    // Apply account filter
    if (selectedFilterAccount !== 'All Accounts') {
      const accountMap: { [key: string]: string } = {
        'john@company.com': 'account1',
        'sales@company.com': 'account2'
      };
      const accountId = accountMap[selectedFilterAccount];
      if (accountId) {
        filtered = filtered.filter(email => email.accountId === accountId);
      }
    }

    // Apply folder filter
    if (selectedFilterFolder !== 'All Folders') {
      filtered = filtered.filter(email => 
        email.folder.toLowerCase() === selectedFilterFolder.toLowerCase()
      );
    }

    setFilteredEmails(filtered);
  }, [emails, searchQuery, selectedCategory, selectedFilterAccount, selectedFilterFolder]);

  const handleEmailSelect = (emailId: string) => {
    setSelectedEmail(emailId);
    // Mark email as read
    setEmails(prev => prev.map(email => 
      email.id === emailId ? { ...email, isRead: true } : email
    ));
  };

  const handleSuggestReply = (emailId: string) => {
    const email = emails.find(e => e.id === emailId);
    if (email) {
      toast.info(`🤖 Generating AI reply for: ${email.subject}`, {
        position: "top-right",
        autoClose: 3000,
      });
    }
  };

  const selectedEmailData = emails.find(email => email.id === selectedEmail);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header />
      
      <div className="flex-1 flex">
        <Sidebar
          selectedFolder={selectedFolder}
          onFolderSelect={setSelectedFolder}
          selectedAccount={selectedAccount}
          onAccountSelect={setSelectedAccount}
        />
        
        <div className="flex-1 flex flex-col">
          <SearchFilters
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            selectedAccount={selectedFilterAccount}
            onAccountChange={setSelectedFilterAccount}
            selectedFolder={selectedFilterFolder}
            onFolderChange={setSelectedFilterFolder}
          />
          
          <div className="flex-1 flex">
            {selectedEmailData ? (
              <EmailDetail
                email={selectedEmailData}
                onBack={() => setSelectedEmail(null)}
                onSuggestReply={handleSuggestReply}
              />
            ) : (
              <EmailList
                emails={filteredEmails}
                selectedEmail={selectedEmail}
                onEmailSelect={handleEmailSelect}
                onSuggestReply={handleSuggestReply}
              />
            )}
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default Home;