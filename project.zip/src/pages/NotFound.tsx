import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Mail } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center">
        <div className="mb-8">
          <div className="mx-auto h-24 w-24 bg-indigo-100 rounded-full flex items-center justify-center mb-6">
            <Mail className="h-12 w-12 text-indigo-600" />
          </div>
          <h1 className="text-6xl font-bold text-zinc-800 mb-4">404</h1>
          <h2 className="text-2xl font-semibold text-zinc-700 mb-2">Page Not Found</h2>
          <p className="text-slate-600 mb-8">
            The page you're looking for doesn't exist or has been moved.
          </p>
        </div>
        
        <Link
          to="/"
          className="inline-flex items-center px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors"
        >
          <Home className="h-4 w-4 mr-2" />
          Back to Email Onebox
        </Link>
      </div>
    </div>
  );
};

export default NotFound;